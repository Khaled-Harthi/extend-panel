# ClawHub Security Audit Export

This archive contains stored scanner outcomes for one ClawHub artifact version.

- manifest.json: artifact metadata for the export
- clawscan.json: ClawScan risk review and final audit verdict material
- skillspector.json: SkillSpector agentic-risk findings
- static-analysis.json: deterministic static scan context
- virustotal.json: VirusTotal engine telemetry
